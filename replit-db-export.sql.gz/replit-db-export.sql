--
-- PostgreSQL database dump
--

\restrict qmT6zCABH75aJQRHJe8aEcc4IBZfhEIm6i87DPp9cVjadXeTmFishH3UMbHWgcv

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: _system; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _system;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: replit_database_migrations_v1; Type: TABLE; Schema: _system; Owner: -
--

CREATE TABLE _system.replit_database_migrations_v1 (
    id bigint NOT NULL,
    build_id text NOT NULL,
    deployment_id text NOT NULL,
    statement_count bigint NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE; Schema: _system; Owner: -
--

CREATE SEQUENCE _system.replit_database_migrations_v1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE OWNED BY; Schema: _system; Owner: -
--

ALTER SEQUENCE _system.replit_database_migrations_v1_id_seq OWNED BY _system.replit_database_migrations_v1.id;


--
-- Name: booking_confirmations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_confirmations (
    id integer NOT NULL,
    rental_id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text DEFAULT ''::text NOT NULL,
    user_email text DEFAULT ''::text NOT NULL,
    confirmed boolean DEFAULT false NOT NULL,
    confirmed_at timestamp without time zone
);


--
-- Name: booking_confirmations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.booking_confirmations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_confirmations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.booking_confirmations_id_seq OWNED BY public.booking_confirmations.id;


--
-- Name: change_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_history (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    change_type text NOT NULL,
    description text NOT NULL,
    metadata text DEFAULT '{}'::text NOT NULL
);


--
-- Name: change_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_history_id_seq OWNED BY public.change_history.id;


--
-- Name: cottage_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cottage_info (
    id integer DEFAULT 1 NOT NULL,
    title text DEFAULT 'Our Cottage'::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    photos_json text DEFAULT '[]'::text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: day_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.day_overrides (
    date text NOT NULL,
    season_override text,
    holiday_override text,
    day_override text
);


--
-- Name: email_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_log (
    id integer NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    recipients text NOT NULL,
    template_type text DEFAULT ''::text NOT NULL,
    rental_id integer,
    subject text DEFAULT ''::text NOT NULL,
    success boolean DEFAULT true NOT NULL,
    error_message text
);


--
-- Name: email_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_log_id_seq OWNED BY public.email_log.id;


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id integer NOT NULL,
    type text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    subject text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- Name: owner_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owner_approvals (
    id integer NOT NULL,
    rental_id integer NOT NULL,
    owner_email text NOT NULL,
    owner_name text DEFAULT ''::text NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    approved_at timestamp without time zone
);


--
-- Name: owner_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.owner_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: owner_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.owner_approvals_id_seq OWNED BY public.owner_approvals.id;


--
-- Name: rentals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rentals (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    renter_name text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    nights integer DEFAULT 0 NOT NULL,
    total_price real DEFAULT 0 NOT NULL,
    rate_type text DEFAULT 'standard'::text NOT NULL,
    extra_details text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending_approval'::text NOT NULL,
    agreed_price real,
    booking_type text DEFAULT 'standard'::text NOT NULL,
    confirmation_token text,
    renter_confirmed boolean DEFAULT false NOT NULL,
    google_calendar_event_id text
);


--
-- Name: rentals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rentals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rentals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rentals_id_seq OWNED BY public.rentals.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id integer DEFAULT 1 NOT NULL,
    base_price real DEFAULT 300 NOT NULL,
    day_monday real DEFAULT 0.95 NOT NULL,
    day_tuesday real DEFAULT 0.95 NOT NULL,
    day_wednesday real DEFAULT 0.95 NOT NULL,
    day_thursday real DEFAULT 0.95 NOT NULL,
    day_friday real DEFAULT 1.1 NOT NULL,
    day_saturday real DEFAULT 1.25 NOT NULL,
    day_sunday real DEFAULT 1.05 NOT NULL,
    seasons_json text DEFAULT '[]'::text NOT NULL,
    holidays_json text DEFAULT '[]'::text NOT NULL,
    family_rate real DEFAULT 200 NOT NULL,
    holidays_by_year_json text DEFAULT '{}'::text NOT NULL,
    owners_json text DEFAULT '[]'::text NOT NULL,
    family_rate_code text DEFAULT ''::text NOT NULL,
    site_password text DEFAULT 'cottage2025'::text,
    google_calendar_id text
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'viewer'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reset_token text,
    reset_token_expiry timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: replit_database_migrations_v1 id; Type: DEFAULT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1 ALTER COLUMN id SET DEFAULT nextval('_system.replit_database_migrations_v1_id_seq'::regclass);


--
-- Name: booking_confirmations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_confirmations ALTER COLUMN id SET DEFAULT nextval('public.booking_confirmations_id_seq'::regclass);


--
-- Name: change_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_history ALTER COLUMN id SET DEFAULT nextval('public.change_history_id_seq'::regclass);


--
-- Name: email_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_log ALTER COLUMN id SET DEFAULT nextval('public.email_log_id_seq'::regclass);


--
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- Name: owner_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_approvals ALTER COLUMN id SET DEFAULT nextval('public.owner_approvals_id_seq'::regclass);


--
-- Name: rentals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rentals ALTER COLUMN id SET DEFAULT nextval('public.rentals_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: replit_database_migrations_v1; Type: TABLE DATA; Schema: _system; Owner: -
--

COPY _system.replit_database_migrations_v1 (id, build_id, deployment_id, statement_count, applied_at) FROM stdin;
1	35b32996-585e-48af-9448-7bdabe0b4683	efa9df3a-902b-4ed0-821f-1c1e15af0197	2	2026-05-02 03:30:42.010265+00
2	415c4de1-2a74-4350-adf6-39de0cb48183	efa9df3a-902b-4ed0-821f-1c1e15af0197	2	2026-05-02 15:34:18.893575+00
3	f3859315-9794-4803-bc7e-6a3360b773a8	efa9df3a-902b-4ed0-821f-1c1e15af0197	7	2026-05-02 16:58:15.377489+00
4	cccfb95f-0985-45de-a7bc-45f9defa4aba	efa9df3a-902b-4ed0-821f-1c1e15af0197	3	2026-05-02 17:20:51.361554+00
5	6c646bec-ee9f-4842-8e56-f0340e3946c3	efa9df3a-902b-4ed0-821f-1c1e15af0197	3	2026-05-02 18:20:19.506594+00
6	4af6909c-ea31-40b9-b7d3-51b6aff2a4f4	efa9df3a-902b-4ed0-821f-1c1e15af0197	1	2026-05-02 20:27:07.899829+00
7	edd76714-e32b-415d-974a-728b9a3dee83	efa9df3a-902b-4ed0-821f-1c1e15af0197	2	2026-05-03 13:20:23.897604+00
\.


--
-- Data for Name: booking_confirmations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_confirmations (id, rental_id, user_id, user_name, user_email, confirmed, confirmed_at) FROM stdin;
1	7	4	Amina	amina461@hotmail.com	f	\N
2	7	6	Sabrina	sabrina.elkefif@gmail.com	f	\N
4	7	3	Karim	karimmartinsaoudi@gmail.com	f	\N
6	7	1	Deavon	deavon1@hotmail.com	f	\N
8	8	6	Sabrina	sabrina.elkefif@gmail.com	f	\N
10	8	3	Karim	karimmartinsaoudi@gmail.com	f	\N
12	8	1	Deavon	deavon1@hotmail.com	t	2026-05-02 20:36:16.829
7	8	4	Amina	amina461@hotmail.com	t	2026-05-02 20:36:44.246
27	11	2	Denis	castonguay99@hotmail.com	t	2026-05-02 22:07:58.814
9	8	2	Denis	castonguay99@hotmail.com	t	2026-05-02 22:08:20.4
3	7	2	Denis	castonguay99@hotmail.com	t	2026-05-02 22:08:29.896
37	13	4	Amina	amina461@hotmail.com	f	\N
38	13	6	Sabrina	sabrina.elkefif@gmail.com	f	\N
39	13	2	Denis	castonguay99@hotmail.com	f	\N
40	13	3	Karim	karimmartinsaoudi@gmail.com	f	\N
41	13	5	David	davidrbkcast99@hotmail.com	f	\N
30	11	1	Deavon	deavon1@hotmail.com	t	2026-05-03 04:39:29.63
36	12	1	Deavon	deavon1@hotmail.com	t	2026-05-03 04:39:40.509
35	12	5	David	davidrbkcast99@hotmail.com	t	2026-05-03 04:39:42.431
34	12	3	Karim	karimmartinsaoudi@gmail.com	t	2026-05-03 04:39:43.197
33	12	2	Denis	castonguay99@hotmail.com	t	2026-05-03 04:39:44.077
32	12	6	Sabrina	sabrina.elkefif@gmail.com	t	2026-05-03 04:39:44.833
31	12	4	Amina	amina461@hotmail.com	t	2026-05-03 04:39:45.759
25	11	4	Amina	amina461@hotmail.com	t	2026-05-03 04:39:52.414
26	11	6	Sabrina	sabrina.elkefif@gmail.com	t	2026-05-03 04:39:55.159
28	11	3	Karim	karimmartinsaoudi@gmail.com	t	2026-05-03 04:39:56.945
29	11	5	David	davidrbkcast99@hotmail.com	t	2026-05-03 04:39:57.914
42	13	1	Deavon	deavon1@hotmail.com	f	\N
5	7	5	David	davidrbkcast99@hotmail.com	t	2026-05-03 16:40:06.361
11	8	5	David	davidrbkcast99@hotmail.com	t	2026-05-03 16:40:10.194
\.


--
-- Data for Name: change_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_history (id, created_at, change_type, description, metadata) FROM stdin;
1	2026-05-02 03:13:12.651262	settings	Settings saved: base $300, family $200, 7 seasons, 7 default holidays	{"basePrice":300,"familyRate":200}
2	2026-05-02 15:17:57.860566	settings	Settings saved: base $300, family $200, 0 seasons, 0 default holidays	{"basePrice":300,"familyRate":200}
3	2026-05-02 15:27:15.485654	settings	Settings saved: base $300, family $200, 6 seasons, 7 default holidays, per-year overrides for 2026, 2027	{"basePrice":300,"familyRate":200}
4	2026-05-02 16:54:52.104363	settings	Settings changed: Owners added: Denis Castonguay	{"basePrice":300,"familyRate":200}
5	2026-05-02 16:55:05.77759	settings	Settings changed: Owners added: Denis Castonguay; Owners removed: Denis Castonguay	{"basePrice":300,"familyRate":200}
6	2026-05-02 17:50:02.543249	settings	Settings changed: Owners removed: Denis Castonguay, Karim, Amina, David, Sabrina	{"basePrice":300,"familyRate":200}
10	2026-05-19 02:50:02.427166	settings	Settings changed: Site password changed	{"basePrice":300,"familyRate":200}
\.


--
-- Data for Name: cottage_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cottage_info (id, title, description, photos_json, updated_at) FROM stdin;
1	Our Cottage		[]	2026-05-02 16:40:55.971338
\.


--
-- Data for Name: day_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.day_overrides (date, season_override, holiday_override, day_override) FROM stdin;
2026-07-14	\N		\N
2026-07-15	\N		\N
2026-07-16	\N		\N
2026-07-19	\N		\N
2026-07-18	\N		\N
2026-07-17	\N		\N
2027-07-19	\N		\N
2027-07-18	\N		\N
2027-07-17	\N		\N
2027-07-16	\N		\N
2027-07-14	\N		\N
2027-07-15	\N		\N
2027-09-06	\N		\N
2027-10-11	\N		\N
\.


--
-- Data for Name: email_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_log (id, sent_at, recipients, template_type, rental_id, subject, success, error_message) FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, type, name, subject, body, updated_at) FROM stdin;
1	renter_confirmed	Renter: Booking Confirmed	Your Cottage Rental is Confirmed — [StartDate] to [EndDate]	Hi [Name],\n\nGreat news! Your cottage rental has been confirmed and we look forward to hosting you.\n\nDates: [StartDate] to [EndDate] ([Nights] nights)\nTotal: $[Total]\nRate: [RateType]\n\nPlease confirm your booking by clicking the link below:\n[ConfirmLink]\n\nIf you have any questions, feel free to reach out.\n\nWarm regards	2026-05-03 13:02:23.643672
2	owner_confirmed	Owners & Admins: Booking Confirmed	Rental Confirmed — [Name] ([StartDate] to [EndDate])	A rental booking has been confirmed.\n\nGuest: [Name]\nPhone: [Phone]\nEmail: [Email]\nDates: [StartDate] to [EndDate] ([Nights] nights)\nTotal: $[Total]\nRate: [RateType]\n\nNotes: [ExtraDetails]	2026-05-03 13:02:23.650045
5	owner_new_booking	Owners: New Booking Request	New Booking Request — [Name] ([StartDate] to [EndDate])	A new booking request has been submitted and requires your approval.\n\nGuest: [Name]\nPhone: [Phone]\nEmail: [Email]\nDates: [StartDate] to [EndDate] ([Nights] nights)\nEstimated Total: $[Total]\nRate: [RateType]\n\nNotes: [ExtraDetails]\n\nPlease log in to approve or decline this booking.	2026-05-19 02:58:26.800588
6	renter_submitted	Renter: Booking Approved, Awaiting Confirmation	Your Cottage Booking Has Been Approved — [StartDate] to [EndDate]	Hi [Name],\n\nGreat news! Your cottage rental request for [StartDate] to [EndDate] has been approved.\n\nYour booking is now awaiting final confirmation. We will be in touch shortly.\n\nDates: [StartDate] to [EndDate] ([Nights] nights)\nTotal: $[Total]\nRate: [RateType]\n\nIf you have any questions, feel free to reach out.\n\nWarm regards	2026-05-19 02:58:26.814021
\.


--
-- Data for Name: owner_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.owner_approvals (id, rental_id, owner_email, owner_name, approved, approved_at) FROM stdin;
\.


--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rentals (id, created_at, renter_name, phone, email, start_date, end_date, nights, total_price, rate_type, extra_details, status, agreed_price, booking_type, confirmation_token, renter_confirmed, google_calendar_event_id) FROM stdin;
7	2026-05-02 20:32:44.669394	David Zika	5149461508		2026-07-17	2026-07-24	7	3348	standard	Pilote AC, First rental from last year, What a good deal got!	confirmed	2000	standard	cbdc87e5-4db0-421f-9c88-1154633e1650	f	\N
6	2026-05-02 19:26:22.072452	Erin…Marthas friend	15149461507	castonguay99@hotmail.com	2026-08-06	2026-08-13	7	2808	standard	Plus Cleanings 150$	confirmed	2600	standard	f19d98fc-19dc-40e0-83ad-335bd695e34b	f	\N
12	2026-05-02 22:09:43.368268	Denis et Sabrina		castonguay99@hotmail.com	2026-07-25	2026-08-03	9	0	personal	Tous bienvenus amener vos amis	confirmed	\N	personal	93fac3db-5af5-4496-a361-6a76cac5cf7b	f	\N
13	2026-05-02 22:16:12.116848	AUTUMN - TEST	5149221865	autumntwin@outlook.com	2026-06-12	2026-06-13	1	286	family	HI TEHE - TEST	pending_approval	200	standard	e15b7bd2-25c3-4a35-b48c-1b97600cb8c3	f	\N
8	2026-05-02 20:35:52.456497	Mark Broady	5149913937		2026-06-26	2026-07-03	7	2913	standard		pending_approval	2000	standard	3e5329e4-d44a-4ff4-94a3-323f4276da84	f	\N
11	2026-05-02 22:05:57.802997	Phillipe Drolet	5147958233		2026-05-29	2026-05-31	2	637.5	standard	They will clean themself.  \nTrusted friend of David.  	confirmed	\N	standard	03138153-e937-4838-b125-b88cb33deb11	f	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, base_price, day_monday, day_tuesday, day_wednesday, day_thursday, day_friday, day_saturday, day_sunday, seasons_json, holidays_json, family_rate, holidays_by_year_json, owners_json, family_rate_code, site_password, google_calendar_id) FROM stdin;
1	300	0.95	0.95	0.95	0.95	1.1	1.25	1.05	[{"name":"Winter","multiplier":1.25,"startDate":"12-15","endDate":"03-15"},{"name":"Low","multiplier":0.85,"startDate":"03-16","endDate":"03-31"},{"name":"Spring","multiplier":0.9,"startDate":"04-01","endDate":"04-31"},{"name":"Summer","multiplier":1.3,"startDate":"06-01","endDate":"08-31"},{"name":"Fall","multiplier":1.15,"startDate":"09-01","endDate":"10-31"},{"name":"Low/Fall","multiplier":0.85,"startDate":"11-01","endDate":"12-14"}]	[{"name":"New Year","boost":0.5},{"name":"St-Jean","boost":0.35},{"name":"Canada Day","boost":0.35},{"name":"Construction Holiday","boost":0.45},{"name":"Labor Day","boost":0.25},{"name":"Thanksgiving","boost":0.25},{"name":"Christmas","boost":0.6}]	200	{"2026":[{"name":"New Year","boost":0.5,"startDate":"01-01","endDate":"01-01"},{"name":"St-Jean","boost":0.35,"startDate":"06-24","endDate":"06-24"},{"name":"Canada Day","boost":0.35,"startDate":"07-01","endDate":"07-01"},{"name":"Construction Holiday","boost":0.45,"startDate":"07-19","endDate":"08-01"},{"name":"Labor Day","boost":0.25,"startDate":"09-07","endDate":"09-07"},{"name":"Thanksgiving","boost":0.25,"startDate":"10-12","endDate":"10-12"},{"name":"Christmas","boost":0.6,"startDate":"12-25","endDate":"12-25"}],"2027":[{"name":"New Year","boost":0.5,"startDate":"01-01","endDate":"01-01"},{"name":"St-Jean","boost":0.35,"startDate":"06-24","endDate":"06-24"},{"name":"Canada Day","boost":0.35,"startDate":"07-01","endDate":"07-01"},{"name":"Construction Holiday","boost":0.45,"startDate":"07-25","endDate":"08-07"},{"name":"Labor Day","boost":0.25,"startDate":"09-06","endDate":"09-06"},{"name":"Thanksgiving","boost":0.25,"startDate":"10-11","endDate":"10-11"},{"name":"Christmas","boost":0.6,"startDate":"12-25","endDate":"12-25"}]}	[{"name":"Deavon Connell","email":"deavon1@hotmail.com"},{"name":"Denis","email":"castonguay99@hotmail.com"},{"name":"Karim","email":"karimmartinsaoudi@gmail.com"},{"name":"Amina","email":"amina461@hotmail.com"},{"name":"David","email":"davidrbkcast99@hotmail.com"},{"name":"Sabrina","email":"sabrina.elkefif@gmail.com"}]	FAMILY	cottage2026	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, password_hash, role, created_at, reset_token, reset_token_expiry) FROM stdin;
1	deavon1@hotmail.com	Deavon	$2b$10$CZ5.2kWwBPDpmu3oYGUfuemDPhN91DugndUh6DDX.VUUYNoQaAc9e	admin	2026-05-02 16:41:24.210723	\N	\N
7	castonguay99@hotmail.com	Denis	$2b$10$PbBmCPkBPsBhD7xzhz9Awe1cfFTOPZ7zdY4jlSFVkk1Ig2CoPvO1G	owner	2026-05-02 17:51:21.227932	\N	\N
8	karimmartinsaoudi@gmail.com	Karim	$2b$10$pBSHWX1n17n4Xh.uHKqMRO.EmnoBEns0adz5w6BcyPylx0Ge78lia	owner	2026-05-02 17:51:52.957756	\N	\N
9	amina461@hotmail.com	Amina	$2b$10$PGH78tZLjRDaz4GN0hpu4Oyjs8Y8Rkx0NeDysps2QPPbL4ygrpSPS	owner	2026-05-02 17:52:12.561625	\N	\N
10	davidrbkcast99@hotmail.com	David	$2b$10$bUpvq6IXhbR/GhbF69pL2uf.2BRtVGqeX7hIuBjOfzHFPDQ475zr2	owner	2026-05-02 17:52:32.961722	\N	\N
11	sabrina.elkefif@gmail.com	Sabrina	$2b$10$uGUmCQqzWJHRekZMjHi1K.0oLYJY7Fj.UGETn0af5/NYo2aX0.qzm	owner	2026-05-02 17:52:55.706682	\N	\N
\.


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE SET; Schema: _system; Owner: -
--

SELECT pg_catalog.setval('_system.replit_database_migrations_v1_id_seq', 7, true);


--
-- Name: booking_confirmations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.booking_confirmations_id_seq', 42, true);


--
-- Name: change_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_history_id_seq', 10, true);


--
-- Name: email_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_log_id_seq', 1, false);


--
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 12, true);


--
-- Name: owner_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.owner_approvals_id_seq', 58, true);


--
-- Name: rentals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rentals_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: replit_database_migrations_v1 replit_database_migrations_v1_pkey; Type: CONSTRAINT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1
    ADD CONSTRAINT replit_database_migrations_v1_pkey PRIMARY KEY (id);


--
-- Name: booking_confirmations booking_confirmations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_confirmations
    ADD CONSTRAINT booking_confirmations_pkey PRIMARY KEY (id);


--
-- Name: booking_confirmations booking_confirmations_rental_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_confirmations
    ADD CONSTRAINT booking_confirmations_rental_id_user_id_key UNIQUE (rental_id, user_id);


--
-- Name: change_history change_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_history
    ADD CONSTRAINT change_history_pkey PRIMARY KEY (id);


--
-- Name: cottage_info cottage_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cottage_info
    ADD CONSTRAINT cottage_info_pkey PRIMARY KEY (id);


--
-- Name: day_overrides day_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.day_overrides
    ADD CONSTRAINT day_overrides_pkey PRIMARY KEY (date);


--
-- Name: email_log email_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_log
    ADD CONSTRAINT email_log_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_type_key UNIQUE (type);


--
-- Name: owner_approvals owner_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_approvals
    ADD CONSTRAINT owner_approvals_pkey PRIMARY KEY (id);


--
-- Name: rentals rentals_confirmation_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_confirmation_token_key UNIQUE (confirmation_token);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_replit_database_migrations_v1_build_id; Type: INDEX; Schema: _system; Owner: -
--

CREATE UNIQUE INDEX idx_replit_database_migrations_v1_build_id ON _system.replit_database_migrations_v1 USING btree (build_id);


--
-- Name: owner_approvals fk_rental; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_approvals
    ADD CONSTRAINT fk_rental FOREIGN KEY (rental_id) REFERENCES public.rentals(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict qmT6zCABH75aJQRHJe8aEcc4IBZfhEIm6i87DPp9cVjadXeTmFishH3UMbHWgcv

